package com.devsu.hackerearth.backend.account.exception;

public class AccountException extends RuntimeException{
    public AccountException(String message){
        super(message);
    }
}
