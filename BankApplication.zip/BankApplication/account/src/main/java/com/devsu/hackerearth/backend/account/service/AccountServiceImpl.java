package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.mapper.AccountMapper;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.exception.AccountException;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;

	public AccountServiceImpl(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
		return accountRepository.findAll().stream().map(AccountMapper::toAccountDto).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        Account account = accountRepository.findById(id).orElseThrow(() -> new AccountException("Account not found"));
		return AccountMapper.toAccountDto(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        Account account = accountRepository.save(AccountMapper.toAccount(accountDto));
		return AccountMapper.toAccountDto(account);
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        accountRepository.findById(accountDto.getId()).orElseThrow(() -> new AccountException("Account not found"));
		Account accountUpdated = accountRepository.save(AccountMapper.toAccount(accountDto));
        return AccountMapper.toAccountDto(accountUpdated);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = accountRepository.findById(id).orElseThrow(() -> new AccountException("Account not found"));
		Account accountUpdated = accountRepository.save(AccountMapper.fromPartialtoAccount(account, partialAccountDto));
        return AccountMapper.toAccountDto(accountUpdated);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        accountRepository.findById(id).orElseThrow(() -> new AccountException("Account not found"));
        accountRepository.deleteById(id);
    }
    
}
