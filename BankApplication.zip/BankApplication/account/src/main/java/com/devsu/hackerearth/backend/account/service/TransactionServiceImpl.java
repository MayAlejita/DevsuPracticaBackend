package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.devsu.hackerearth.backend.account.exception.BalanceException;
import com.devsu.hackerearth.backend.account.exception.TransactionException;
import com.devsu.hackerearth.backend.account.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountService accountService;

    public TransactionServiceImpl(TransactionRepository transactionRepository,
            AccountService accountService) {
        this.transactionRepository = transactionRepository;
        this.accountService = accountService;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll().stream().map(TransactionMapper::toDto).collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        Transaction transaction = transactionRepository.findById(id)
                .orElseThrow(() -> new TransactionException("Transaction not found"));
        return TransactionMapper.toDto(transaction);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        TransactionDto transactionDtoBdd = getLastByAccountId(transactionDto.getAccountId());
        transactionDto.setBalance(transactionDtoBdd.getBalance() + transactionDto.getAmount());

        if (transactionDto.getBalance() <= 0) {
            throw new BalanceException("Saldo no disponible");
        }

        transactionRepository.save(TransactionMapper.toTransaction(transactionDto));
        return transactionDto;
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report

        WebClient webClient = WebClient.create("http://localhost:8001/api/clients");
        ClientDto clientDto = webClient.get()
                .uri("/" + clientId)
                .retrieve()
                .bodyToMono(ClientDto.class)
                .block();

        Set<Long> accountsId = accountService.getAll()
                .stream()
                .filter(a -> a.getClientId() == clientId)
                .map(ac -> ac.getId())
                .collect(Collectors.toSet());

        List<BankStatementDto> bankStatements = transactionRepository.findAccountByClientAndDates(accountsId,
                dateTransactionStart, dateTransactionEnd);

        bankStatements.stream()
                .forEach(a -> a.setClient(clientDto.getName()));

        return bankStatements;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        Transaction transaction = transactionRepository.getLastByAccountId(accountId);

        if (transaction == null) {
            throw new TransactionException("Transaction not found");
        }
        return TransactionMapper.toDto(transaction);
    }

}
