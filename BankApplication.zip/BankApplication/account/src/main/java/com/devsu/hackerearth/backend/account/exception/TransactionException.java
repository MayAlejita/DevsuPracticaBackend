package com.devsu.hackerearth.backend.account.exception;

public class TransactionException extends RuntimeException {
    public TransactionException(String message) {
        super(message);
    }

}
