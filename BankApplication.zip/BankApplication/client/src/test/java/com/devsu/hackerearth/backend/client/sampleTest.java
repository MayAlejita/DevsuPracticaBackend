package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@SpringBootTest
public class sampleTest {

    private ClientService clientService = mock(ClientService.class);
    private ClientController clientController = new ClientController(clientService);

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    void createClientTest() {
        // Arrange
        ClientDto newClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999", true);
        ClientDto createdClient = new ClientDto(1L, "Dni", "Name", "Password", "Gender", 1, "Address", "9999999999",
                true);
        when(clientService.create(newClient)).thenReturn(createdClient);

        // Act
        ResponseEntity<ClientDto> response = clientController.create(newClient);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(createdClient, response.getBody());
    }

    @Test
    void updateClienteTest() {
        ClientDto clientDto = new ClientDto(2L, "Dni", "Name", "Password", "Gender", 50, "Address", "00000000", true);
        ClientDto updatedClient = new ClientDto(2L, "Dni", "Name", "Password", "Gender", 50, "Address", "00000000",
                true);
        when(clientService.update(clientDto)).thenReturn(updatedClient);

        ResponseEntity<ClientDto> response = clientController.update(updatedClient.getId(), updatedClient);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedClient, response.getBody());
    }

    // Integration Test
    @Test
    void getClientByIdIntegrationTest() {

        ClientDto client = new ClientDto(3L, "Dni", "Name", "Password", "Gender", 20, "Address", "11111111", true);
        ResponseEntity<ClientDto> response = testRestTemplate.getForEntity("/api/clientes/" + client.getId(),
                ClientDto.class);
        assertEquals(response.getStatusCode(), HttpStatus.OK);

    }

}
